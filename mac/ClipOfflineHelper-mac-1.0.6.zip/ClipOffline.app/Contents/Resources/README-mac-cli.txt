ClipOffline desktop helper (macOS, CLI bundle)
------------------------------------------------
This archive contains the Python-based helper used by ClipOffline to run downloads
on your machine. It is not a signed .app bundle; run it directly with Python.

Requirements
- macOS with Python 3.8+ available in PATH (run `python3 --version` to confirm).
- Internet access to reach your ClipOffline deployment.

Quick start
1) Unzip this archive somewhere convenient, e.g. `~/ClipOfflineHelper`.
2) Open Terminal and move into that folder.
3) Create and activate a virtual environment (recommended):
   python3 -m venv .venv
   source .venv/bin/activate
4) Install dependencies:
   pip install -r requirements.txt
5) Start a job on clipoffline.com and copy the desktop token.
6) Run the helper with the token or the `clipoffline://job?token=...` URL:
   python3 helper_main.py "clipoffline://job?token=<TOKEN>"
   # or
   python3 helper_main.py "<TOKEN>"

What the helper does
- Resolves the job from the ClipOffline API.
- Marks it running, downloads media locally via yt_dlp into `~/Downloads/ClipOffline`,
  then marks it complete (or failed on errors).

Notes
- This CLI bundle is for development and interim testing. A signed macOS app bundle
  can still be produced from `desktop-helper/ClipOfflineHelper.spec` if needed.
- If your backend requires a helper secret, set `CLIPOFFLINE_HELPER_SECRET` in your
  environment before running the helper.
