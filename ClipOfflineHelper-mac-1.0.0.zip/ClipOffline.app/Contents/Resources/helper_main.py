import os
import sys
import traceback
from typing import Optional, Dict, Any
from urllib.parse import urlparse, parse_qs

import requests
from yt_dlp import YoutubeDL
from datetime import datetime


# Set CLIPOFFLINE_HELPER_DEBUG=1 in the environment if you want file logs.


# Default to production site; override with CLIPOFFLINE_API_BASE for local dev.
DEFAULT_API_BASE = "https://www.clipoffline.com"
API_BASE = os.environ.get("CLIPOFFLINE_API_BASE", DEFAULT_API_BASE).rstrip("/")
HELPER_SECRET = os.environ.get("CLIPOFFLINE_HELPER_SECRET")
DOWNLOADS_DIR = os.environ.get(
    "CLIPOFFLINE_HELPER_DOWNLOADS_DIR",
    os.path.join(os.path.expanduser("~"), "Downloads", "ClipOffline"),
)
os.makedirs(DOWNLOADS_DIR, exist_ok=True)

DEBUG_LOG = os.environ.get("CLIPOFFLINE_HELPER_DEBUG", "").lower() in ("1", "true", "yes")
LOG_PATH = os.path.expanduser("~/clipoffline-helper-log.txt")

def log(msg: str) -> None:
    if not DEBUG_LOG:
        return
    try:
        with open(LOG_PATH, "a") as f:
            f.write(f"[{datetime.now().isoformat()}] {msg}\n")
    except Exception:
        pass


def extract_token_from_arg(arg: str) -> Optional[str]:
    """
    Accepts either:
      - a plain token string ("abc123")
      - a full URI like "clipoffline://job?token=abc123"
    Returns the token, or None if it cannot be parsed.
    """
    if not arg:
        return None

    if arg.startswith("clipoffline://"):
        parsed = urlparse(arg)
        if parsed.scheme != "clipoffline":
            return None
        token_values = parse_qs(parsed.query).get("token")
        if token_values and token_values[0]:
            return token_values[0]
        return None

    # Fallback: treat as plain token
    token = arg.strip()
    return token or None


def _headers() -> Dict[str, str]:
    headers = {"Content-Type": "application/json"}
    if HELPER_SECRET:
        headers["X-ClipOffline-Helper-Secret"] = HELPER_SECRET
    return headers


def resolve_job(token: str) -> Dict[str, Any]:
    print(f"[helper] Resolving job token={token}")
    log(f"[helper] resolve_job: API_BASE={API_BASE} token={token}")
    response = requests.get(f"{API_BASE}/api/jobs/resolve", params={"token": token}, headers=_headers())
    log(f"[helper] resolve_job: status={response.status_code}")
    if response.status_code != 200:
        raise RuntimeError(f"Failed to resolve job: {response.status_code} {response.text}")
    return response.json()


def mark_job_start(token: str) -> None:
    print(f"[helper] Marking job start token={token}")
    response = requests.post(f"{API_BASE}/api/jobs/start", json={"token": token}, headers=_headers())
    if not response.ok:
        raise RuntimeError(f"Failed to mark job start: {response.status_code} {response.text}")


def mark_job_complete(token: str, error_message: Optional[str] = None) -> None:
    status = "complete" if error_message is None else "failed"
    print(f"[helper] Marking job {status} token={token}")
    payload: Dict[str, Any] = {"token": token}
    if error_message:
        payload["errorMessage"] = error_message
    response = requests.post(f"{API_BASE}/api/jobs/complete", json=payload, headers=_headers())
    if not response.ok:
        raise RuntimeError(f"Failed to mark job {status}: {response.status_code} {response.text}")


def build_format_string(format: str, quality: str) -> str:
    """
    Decide on a yt_dlp format string based on job format/quality.

    format: "mp4" for video, "mp3" for audio-only mode (we do not guarantee MP4/MP3 containers).
    quality: "auto" | "low" | "medium" | "high"
    """
    quality = (quality or "auto").lower()  # or "auto" if you prefer
    fmt = (format or "").lower()

    if fmt == "mp3":
        # AUDIO-ONLY MODE:
        # Just grab the best available audio track as-is. No transcoding,
        # no ffmpeg, no container guarantee (often WebM/Opus or M4A).
        return "bestaudio/best"

    # VIDEO MODE (default, any format that isn't "mp3").
    # We avoid bestvideo+bestaudio to avoid needing ffmpeg to merge.
    if quality == "low":
        return (
            "best[height<=480][acodec!=none][vcodec!=none]/"
            "best[height<=480][acodec!=none]/"
            "best[acodec!=none]"
        )
    if quality == "medium":
        return (
            "best[height<=720][acodec!=none][vcodec!=none]/"
            "best[height<=720][acodec!=none]/"
            "best[acodec!=none]"
        )
    if quality in ("high", "auto"):
        # Let yt_dlp pick the best single muxed audio+video.
        return "best[acodec!=none]/best"

    # Fallback
    return "best[acodec!=none]"


def resolve_downloaded_path(info: Dict[str, Any], downloaded_file: Optional[str]) -> str:
    candidate = downloaded_file or info.get("_filename")

    if not candidate and isinstance(info.get("requested_downloads"), list):
        requested = info["requested_downloads"][0]
        candidate = requested.get("filepath") or requested.get("filename")

    if not candidate:
        raise RuntimeError("Could not determine downloaded file path from yt_dlp info")

    if os.path.isabs(candidate):
        final_path = candidate
    else:
        final_path = os.path.join(DOWNLOADS_DIR, candidate)

    if not os.path.exists(final_path):
        raise FileNotFoundError(f"Downloaded file not found at {final_path}")

    return final_path


def run_download_job(job: Dict[str, Any]) -> Dict[str, Any]:
    """
    Given a resolved job object from /api/jobs/resolve, perform a local download
    using yt_dlp and return metadata:

      { "path": "/path/to/file", "size": 12345 }
    """
    url = job.get("url")
    fmt = (job.get("format") or "").lower()
    quality = (job.get("quality") or "auto").lower()

    log(f"[helper] run_download_job: url={url} format={fmt} quality={quality}")
    if not url or not isinstance(url, str):
        raise ValueError("Job is missing a valid 'url' field")

    format_string = build_format_string(fmt, quality)
    log(f"[helper] run_download_job: yt_dlp starting with format={format_string}")
    
    downloaded_file: Optional[str] = None

    def progress_hook(data: Dict[str, Any]) -> None:
        nonlocal downloaded_file
        if data.get("status") == "finished":
            downloaded_file = data.get("info_dict", {}).get("_filename") or data.get("filename")

    ydl_opts: Dict[str, Any] = {
        "format": format_string,
        "outtmpl": os.path.join(DOWNLOADS_DIR, "%(title)s.%(ext)s"),
        "noplaylist": True,
        "quiet": True,
        "progress_hooks": [progress_hook],
    }

    print(f"[helper] Starting yt_dlp download: url={url} format={fmt} quality={quality}")
    with YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(url, download=True)

    final_path = resolve_downloaded_path(info, downloaded_file)
    size = os.path.getsize(final_path)

    log(f"[helper] run_download_job: final_path={final_path} size={size}")
    print(f"[helper] Download complete: {final_path} ({size} bytes)")
    return {"path": final_path, "size": size}


def main() -> None:
    if len(sys.argv) < 2:
        print("Usage: ClipOfflineHelper <job-token-or-uri>", file=sys.stderr)
        log("[helper] main: missing token argument")
        sys.exit(1)

    raw_arg = sys.argv[1]
    token = extract_token_from_arg(raw_arg)
    if not token:
        msg = f"Could not extract token from argument: {raw_arg}"
        print(msg, file=sys.stderr)
        log(f"[helper] main: {msg}")
        sys.exit(1)

    print(f"[helper] Received token: {token}")

    try:
        job = resolve_job(token)
        log(f"[helper] main: resolved job id={job.get('id')} url={job.get('url')} format={job.get('format')} quality={job.get('quality')}")
        print(
            f"[helper] Resolved job: id={job.get('id')} url={job.get('url')} "
            f"format={job.get('format')} quality={job.get('quality')}"
        )

        mark_job_start(token)
        log("[helper] main: marked job start")
        print("[helper] Marked job as running")

        # Perform real download
        result = run_download_job(job)
        log(f"[helper] main: download complete path={result['path']} size={result['size']}")
        print(f"[helper] Job succeeded: {result['path']} ({result['size']} bytes)")

        mark_job_complete(token)
        log("[helper] main: marked job complete")
        print("[helper] Marked job as complete")

    except Exception as exc:
        tb = traceback.format_exc()
        log(f"[helper] ERROR: {exc!r}\n{tb}")
        print(f"[helper] Error handling job: {exc}", file=sys.stderr)
        # Try to report failure if we have a token
        try:
            mark_job_complete(token, error_message=str(exc))
            log("[helper] main: reported job failure to API")
        except Exception as exc2:
            log(f"[helper] main: failed to report job failure: {exc2!r}")
            print(f"[helper] Failed to report job failure: {exc2}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
